<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

include ('../../../inc/includes.php');

Session::checkRight('config', UPDATE);

$notification_websocket = new PluginTelegrambotNotificationWebsocketSetting();

if (isset($_POST['test_connection'])) {
    $token = isset($_POST['token']) ? $_POST['token'] : PluginTelegrambotBot::getConfig('token');
    $username = isset($_POST['bot_username']) ? $_POST['bot_username'] : PluginTelegrambotBot::getConfig('bot_username');
    
    $result = PluginTelegrambotBot::testBotConnection($token, $username);
    
    if ($result['success']) {
        Session::addMessageAfterRedirect('Conexão com o bot Telegram bem-sucedida! ' . $result['message'], false, INFO);
    } else {
        Session::addMessageAfterRedirect('Erro ao conectar com o bot: ' . $result['message'], false, ERROR);
    }
    Html::back();

} else if (isset($_POST['send_test_message']) || isset($_GET['send_test']) || isset($_REQUEST['send_test'])) {
    // Pegar user_id de diferentes fontes
    $user_id = $_POST['user_id'] ?? $_GET['user_id'] ?? $_REQUEST['user_id'] ?? null;
    
    if ($user_id) {
        $message = "🧪 *Teste de notificação do GLPI*\n\n";
        $message .= "📅 Data/Hora: " . date('d/m/Y H:i:s') . "\n";
        $message .= "👤 Usuário GLPI ID: " . $user_id . "\n\n";
        $message .= "✅ Se você recebeu esta mensagem, o bot está funcionando corretamente!";
        
        PluginTelegrambotBot::sendMessage($user_id, $message);
        
        Session::addMessageAfterRedirect("Mensagem de teste enviada para o usuário ID: $user_id", false, INFO);
    }
    Html::back();

} else if (isset($_POST['update'])) {
    $token = isset($_POST['token']) ? $_POST['token'] : '';
    $username = isset($_POST['bot_username']) ? $_POST['bot_username'] : '';
    
    PluginTelegrambotBot::setConfig('token', $token);
    PluginTelegrambotBot::setConfig('bot_username', $username);
    
    // Salvar técnicos globais
    for ($i = 1; $i <= 3; $i++) {
        $key = "global_tech_$i";
        if (isset($_POST[$key])) {
            PluginTelegrambotBot::setConfig($key, $_POST[$key]);
        }
    }
    
    Session::addMessageAfterRedirect('Configurações salvas com sucesso!', false, INFO);
    Html::back();
}

Html::header(
    Notification::getTypeName(Session::getPluralNumber()),
    $_SERVER['PHP_SELF'],
    'config',
    'notification',
    'config'
);

$notification_websocket->display(['id' => 1]);

Html::footer();

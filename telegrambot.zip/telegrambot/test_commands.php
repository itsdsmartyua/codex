#!/usr/bin/env php
<?php
/**
 * Script de teste para verificar se os comandos do bot estão funcionando
 * 
 * Execute este script manualmente para processar as mensagens pendentes do Telegram
 * e verificar se os comandos /help, /newticket, etc. estão respondendo.
 * 
 * Uso:
 *   php test_commands.php
 * 
 * Ou no Windows:
 *   C:\xampp\php\php.exe test_commands.php
 */

// Define GLPI root
define('GLPI_ROOT', dirname(dirname(dirname(__DIR__))));

// Verifica se o arquivo existe
if (!file_exists(GLPI_ROOT . '/inc/includes.php')) {
    die("ERRO: GLPI não encontrado em " . GLPI_ROOT . "\n");
}

// Load GLPI
include (GLPI_ROOT . "/inc/includes.php");

echo "\n";
echo "=========================================\n";
echo "  TESTE DE COMANDOS DO TELEGRAM BOT\n";
echo "=========================================\n\n";

// Carrega o plugin
$plugin = new Plugin();
if (!$plugin->isActivated('telegrambot')) {
    die("ERRO: Plugin TelegramBot não está ativado!\n");
}

echo "✓ Plugin TelegramBot está ativado\n\n";

// Verifica configuração
$token = Config::getConfigurationValues('plugin:telegrambot')['token'] ?? '';
$bot_username = Config::getConfigurationValues('plugin:telegrambot')['bot_username'] ?? '';

if (empty($token)) {
    die("ERRO: Token do bot não está configurado!\n");
}

echo "✓ Token do bot: " . substr($token, 0, 10) . "...\n";
echo "✓ Bot username: @$bot_username\n\n";

// Lista os comandos disponíveis
echo "Comandos configurados:\n";
foreach (PluginTelegrambotBot::$commands_list as $cmd) {
    echo "  $cmd\n";
}
echo "\n";

// Verifica se a pasta de comandos existe
$commands_path = __DIR__ . '/Commands/';
echo "Pasta de comandos: $commands_path\n";

if (!is_dir($commands_path)) {
    die("ERRO: Pasta de comandos não existe!\n");
}

echo "✓ Pasta de comandos existe\n\n";

// Lista os arquivos de comando
echo "Arquivos de comando encontrados:\n";
$command_files = glob($commands_path . '*.php');
foreach ($command_files as $file) {
    echo "  - " . basename($file) . "\n";
}
echo "\n";

// Testa a conexão com o Telegram
echo "Testando conexão com Telegram API...\n";
$test_result = PluginTelegrambotBot::testBotConnection($token, $bot_username);

if ($test_result['success']) {
    echo "✓ " . $test_result['message'] . "\n\n";
} else {
    die("✗ ERRO: " . $test_result['message'] . "\n");
}

// Processa as atualizações (mensagens pendentes)
echo "Processando mensagens pendentes do Telegram...\n";
echo "(Se você enviou /help ou outro comando, ele será processado agora)\n\n";

try {
    $response = PluginTelegrambotBot::getUpdates();
    
    if ($response == 'ok') {
        echo "✓ Mensagens processadas com sucesso!\n";
        echo "\n";
        echo "Agora verifique o Telegram para ver se o bot respondeu.\n";
    } else {
        echo "✗ Erro ao processar mensagens: $response\n";
    }
} catch (Exception $e) {
    echo "✗ ERRO: " . $e->getMessage() . "\n";
}

echo "\n";
echo "=========================================\n";
echo "  TESTE CONCLUÍDO\n";
echo "=========================================\n";
echo "\n";
echo "PRÓXIMOS PASSOS:\n";
echo "1. Verifique o Telegram para ver se o bot respondeu\n";
echo "2. Se não respondeu, envie /help novamente e execute este script\n";
echo "3. Configure o cron para executar automaticamente\n";
echo "\n";

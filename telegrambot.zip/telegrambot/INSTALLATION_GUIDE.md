# 📖 Guia Completo de Instalação - TelegramBot para GLPI

Este guia foi criado para ajudar iniciantes a instalar e configurar o plugin TelegramBot no GLPI, mesmo sem experiência prévia.

## 📋 Índice

1. [Pré-requisitos](#1-pré-requisitos)
2. [Criando o Bot no Telegram](#2-criando-o-bot-no-telegram)
3. [Instalando o Plugin no GLPI](#3-instalando-o-plugin-no-glpi)
4. [Configurando o Plugin](#4-configurando-o-plugin)
5. [Configurando Usuários](#5-configurando-usuários)
6. [Configurando Notificações](#6-configurando-notificações)
7. [Ativando o Cron](#7-ativando-o-cron)
8. [Testando o Funcionamento](#8-testando-o-funcionamento)
9. [Configurações Avançadas](#9-configurações-avançadas)
10. [Solução de Problemas](#10-solução-de-problemas)

---

## 1. Pré-requisitos

Antes de começar, verifique se você tem:

### ✅ No Servidor
- **GLPI** instalado (versão 9.4, 9.5, 10.x ou 11.x)
- **PHP** versão 7.4 ou superior (recomendado PHP 8.x)
- **MySQL** ou **MariaDB**
- Acesso de **administrador** no GLPI
- Acesso ao servidor via **FTP/SSH** ou painel de controle

### ✅ No Telegram
- Conta no **Telegram** (aplicativo no celular ou desktop)
- Acesso ao bot **@BotFather**

### ✅ Conhecimentos Básicos
- Saber acessar o painel administrativo do GLPI
- Saber fazer upload de arquivos para o servidor (ou usar Git)
- *Opcional*: Conhecimento básico de linha de comando

---

## 2. Criando o Bot no Telegram

O primeiro passo é criar seu bot no Telegram. Siga estas etapas:

### Passo 2.1: Abrir o BotFather

1. **Abra o Telegram** (celular ou computador)
2. Na barra de pesquisa, digite: `@BotFather`
3. Clique no resultado que mostra o bot oficial (tem um ✓ azul de verificado)
4. Clique em **"Iniciar"** ou **"Start"**

### Passo 2.2: Criar o Bot

1. No chat com o BotFather, digite: `/newbot`
2. O BotFather vai perguntar:
   ```
   Alright, a new bot. How are we going to call it? 
   Please choose a name for your bot.
   ```
3. Digite o **nome** do seu bot (pode ser qualquer coisa):
   ```
   Exemplo: GLPI Notificações
   ```

4. O BotFather vai pedir o **username** (tem que terminar com "bot"):
   ```
   Good. Now let's choose a username for your bot.
   It must end in 'bot'.
   ```
5. Digite o username (sem espaços):
   ```
   Exemplo: glpi_notificacoes_bot
   ```

### Passo 2.3: Guardar as Informações

O BotFather vai responder com algo assim:

```
Done! Congratulations on your new bot.

Use this token to access the HTTP API:
1234567890:ABCdefGHIjklMNOpqrsTUVwxyz1234567

Keep your token secure and store it safely.

Your bot username: @glpi_notificacoes_bot
```

**⚠️ IMPORTANTE:**
- **Copie e guarde** o **token** (a linha grande com números e letras)
- **Copie e guarde** o **username** (sem o @)
- **NÃO COMPARTILHE** o token com ninguém!

### Passo 2.4: Configurar Privacidade (Opcional)

Se você quiser que o bot receba mensagens em grupos:

1. No BotFather, digite: `/setprivacy`
2. Selecione seu bot
3. Escolha **"Disable"**

---

## 3. Instalando o Plugin no GLPI

Agora vamos instalar o plugin no seu servidor GLPI.

### Opção A: Download Manual

#### Passo 3.1: Baixar o Plugin

1. Acesse: https://github.com/pluginsGLPI/telegrambot
2. Clique no botão verde **"Code"** > **"Download ZIP"**
3. Salve o arquivo no seu computador
4. **Descompacte** o arquivo ZIP

#### Passo 3.2: Enviar para o Servidor

1. Acesse seu servidor via **FTP** (FileZilla, WinSCP, etc.) ou **painel de controle**
2. Navegue até a pasta: `/var/www/html/glpi/plugins/` (ou `C:\xampp\htdocs\glpi\plugins\` no Windows)
3. Crie uma pasta chamada **`telegrambot`** (tudo minúsculo, sem espaços)
4. **Faça upload** de todos os arquivos descompactados para dentro da pasta `telegrambot`

### Opção B: Usando Git (Avançado)

Se você tem acesso SSH ao servidor:

```bash
cd /var/www/html/glpi/plugins/
git clone https://github.com/pluginsGLPI/telegrambot.git
cd telegrambot
composer install --no-dev
```

#### Passo 3.3: Verificar Permissões

Certifique-se que o servidor web pode ler os arquivos:

```bash
# Linux/Ubuntu
sudo chown -R www-data:www-data /var/www/html/glpi/plugins/telegrambot
sudo chmod -R 755 /var/www/html/glpi/plugins/telegrambot
```

### Passo 3.4: Ativar no GLPI

1. **Faça login** no GLPI como administrador
2. No menu superior, clique em **"Configurar"**
3. No menu lateral esquerdo, clique em **"Plugins"**
4. Você verá uma lista de plugins
5. Procure por **"TelegramBot"** na lista
6. Na coluna **"Ação"**, clique no ícone de **"Instalar"** (📥)
7. Aguarde a instalação concluir
8. Depois, clique no ícone de **"Ativar"** (✅)

**✅ Pronto!** O plugin está instalado e ativado!

---

## 4. Configurando o Plugin

Agora vamos configurar o bot com o token que você recebeu.

### Passo 4.1: Acessar Configurações

1. No menu do GLPI, clique em **"Configurar"**
2. No menu lateral esquerdo, clique em **"Notificações"**
3. Você verá uma seção **"Telegram notifications"**

### Passo 4.2: Inserir Credenciais

1. **Bot token**: Cole o token que o BotFather te deu
   ```
   Exemplo: 1234567890:ABCdefGHIjklMNOpqrsTUVwxyz1234567
   ```

2. **Bot username**: Digite o username do bot (SEM o @)
   ```
   Exemplo: glpi_notificacoes_bot
   ```

### Passo 4.3: Testar Conexão

1. Clique no botão **"Testar Conexão"** (🧪)
2. Se tudo estiver correto, você verá:
   ```
   ✅ Conexão com o bot Telegram bem-sucedida! Bot conectado: @seu_bot
   ```
3. Se der erro, verifique se copiou o token corretamente

### Passo 4.4: Salvar

1. Clique no botão **"Salvar"**
2. Aguarde a mensagem de confirmação

---

## 5. Configurando Usuários

Para receber notificações, cada usuário precisa:

### Passo 5.1: Usuário Envia /start no Telegram

**Cada pessoa** que vai receber notificações deve:

1. Abrir o **Telegram**
2. Procurar pelo bot (usando o username que você criou)
   ```
   Exemplo: @glpi_notificacoes_bot
   ```
3. Abrir o chat com o bot
4. Enviar a mensagem: `/start`
5. O bot vai responder confirmando

### Passo 5.2: Registrar no GLPI

1. No GLPI, vá em **"Administração"** > **"Usuários"**
2. Clique no usuário que você quer configurar
3. Role a página até o final
4. Você verá um campo: **"Telegram username"**

**Você tem duas opções:**

#### Opção A: Usar o Username do Telegram
Se a pessoa tem um @username no Telegram:
- Digite o username **sem o @**
- Exemplo: `joao_silva`

#### Opção B: Usar o ID do Telegram
Se a pessoa NÃO tem username configurado:

1. Execute o cron (veremos como no passo 7)
2. No banco de dados, veja qual ID foi registrado:
   ```sql
   SELECT id, first_name, username FROM glpi_plugin_telegrambot_user;
   ```
3. Copie o **ID** (número grande)
4. Cole no campo "Telegram username" do usuário no GLPI

### Passo 5.3: Salvar

1. Clique em **"Atualizar"**
2. Repita para cada usuário

---

## 6. Configurando Notificações

Agora vamos fazer o GLPI enviar notificações para o Telegram.

### Passo 6.1: Ativar Notificações

1. Vá em **"Configurar"** > **"Notificações"** > **"Notificações"**
2. Procure pela notificação que você quer ativar (ex: "Novo chamado")
3. Clique nela
4. Verifique se **"Ativo"** está em **"Sim"**

### Passo 6.2: Adicionar Template Telegram

1. Ainda na notificação, clique na aba **"Templates"** (menu esquerdo)
2. Clique em **"Adicionar um template"**
3. Em **"Modo"**, selecione: **"Telegram"**
4. Em **"Notification template"**, selecione o template desejado
5. Clique em **"Adicionar"**

### Passo 6.3: Configurar Destinatários

1. Clique na aba **"Destinatários"** (menu esquerdo)
2. Adicione os destinatários que devem receber:
   - **Requerente** (quem abriu o chamado)
   - **Técnico responsável**
   - **Observador**
   - etc.
3. Clique em **"Atualizar"**

### Passo 6.4: Criar Template (Se Necessário)

Se você não tem um template, crie um:

1. Vá em **"Configurar"** > **"Notificações"** > **"Modelos de notificação"**
2. Clique em **"Adicionar"**
3. Dê um nome: "Notificação Telegram - Novo Chamado"
4. Em **"Tipo"**, selecione: **"Ticket"**
5. Clique em **"Adicionar"**
6. Na próxima tela, preencha:
   - **Subject**: `Novo Chamado ##ticket.id##`
   - **Email text body**:
     ```
     🎫 Novo Chamado Criado

     ID: ##ticket.id##
     Título: ##ticket.title##
     Descrição: ##ticket.description##
     Prioridade: ##ticket.priority##
     Solicitante: ##ticket.author##
     ```
7. Clique em **"Adicionar"**

---

## 7. Ativando o Cron

O cron é responsável por processar as mensagens do Telegram.

### Passo 7.1: Configurar no GLPI

1. Vá em **"Administração"** > **"Automática"**
2. Procure por **"messagelistener"**
3. Clique nele
4. Você verá a configuração do cron
5. Clique em **"Executar"** para testar manualmente

### Passo 7.2: Executar Automaticamente (Linux)

Se você quer que execute automaticamente a cada 5 minutos:

1. Acesse o servidor via SSH
2. Edite o crontab:
   ```bash
   crontab -e
   ```
3. Adicione esta linha:
   ```bash
   */5 * * * * php /var/www/html/glpi/front/cron.php
   ```
4. Salve e saia

### Passo 7.3: Executar Automaticamente (Windows)

No Windows com XAMPP:

1. Crie um arquivo `.bat` com este conteúdo:
   ```batch
   C:\xampp\php\php.exe C:\xampp\htdocs\glpi\front\cron.php
   ```
2. Use o **Agendador de Tarefas** do Windows
3. Configure para executar a cada 5 minutos

---

## 8. Testando o Funcionamento

Vamos testar se tudo está funcionando!

### Teste 1: Enviar Mensagem de Teste

1. Vá em **"Configurar"** > **"Notificações"**
2. Role até a seção **"Usuários configurados para receber notificações"**
3. Você verá uma tabela com os usuários
4. Na coluna **"Status"**, verifique se está **"✓ Conectado"**
5. Clique no botão **"Enviar Teste"**
6. **Abra o Telegram** e veja se recebeu a mensagem:
   ```
   🧪 Teste de notificação do GLPI
   
   📅 Data/Hora: 18/12/2025 15:30:00
   👤 Usuário GLPI ID: 2
   
   ✅ Se você recebeu esta mensagem, o bot está funcionando corretamente!
   ```

### Teste 2: Criar um Chamado

1. No GLPI, vá em **"Assistência"** > **"Criar um chamado"**
2. Preencha:
   - **Título**: "Teste de notificação Telegram"
   - **Descrição**: "Testando o bot"
   - **Solicitante**: Selecione o usuário que você configurou
3. Clique em **"Adicionar"**
4. **Abra o Telegram** e veja se recebeu a notificação!

**✅ Se você recebeu as mensagens, está tudo funcionando!**

---

## 9. Configurações Avançadas

### 9.1: Técnicos Globais

Configure até 3 técnicos que receberão **todas** as notificações:

1. Vá em **"Configurar"** > **"Notificações"**
2. Na seção **"Técnicos que receberão todas as notificações"**
3. Selecione até 3 técnicos nos dropdowns
4. Clique em **"Salvar"**

**Uso:**
- Supervisores que precisam acompanhar tudo
- Equipe de plantão
- Backup quando usuários não têm Telegram

### 9.2: Notificações em Grupos

Se você quer que as notificações vão para um grupo:

1. **Crie um grupo** no Telegram
2. **Adicione o bot** ao grupo
3. No grupo, envie: `/start`
4. Execute o cron no GLPI
5. No banco de dados, pegue o **chat_id** do grupo:
   ```sql
   SELECT id, type FROM glpi_plugin_telegrambot_chat WHERE type = 'group';
   ```
6. Use esse ID na configuração do usuário no GLPI

---

## 10. Solução de Problemas

### ❌ Problema: "Comandos do bot não respondem (/help, /newticket, etc.)"

**Causa Comum:**
O bot só processa mensagens quando o **cron está rodando**. Diferente do comando `/start` que é instantâneo, os outros comandos precisam do cron.

**Solução:**
1. **Execute o cron manualmente:**
   - No GLPI, vá em **"Administração"** > **"Automática"**
   - Procure por **"messagelistener"**
   - Clique em **"Executar"**

2. **Teste novamente:**
   - Envie `/help` no Telegram
   - Aguarde alguns segundos
   - O bot deve responder com a lista de comandos

3. **Configure execução automática:**
   - Linux: Configure o crontab (veja seção 7.2)
   - Windows: Configure o Agendador de Tarefas (veja seção 7.3)

4. **Verifique se o comando está registrado:**
   Execute no MySQL:
   ```sql
   SELECT * FROM glpi_plugin_telegrambot_command;
   ```
   
5. **Verifique permissões do bot:**
   - No BotFather, digite `/mybots`
   - Selecione seu bot
   - **Bot Settings** > **Group Privacy**
   - Configure como **"Disabled"** se quiser usar em grupos

### ❌ Problema: "Usuário não conectado"

**Solução:**
1. O usuário enviou `/start` para o bot?
2. O cron foi executado após enviar `/start`?
3. O username/ID está correto no cadastro do usuário?

### ❌ Problema: "Não recebo notificações"

**Checklist:**
- [ ] Bot está configurado com token correto?
- [ ] Usuário enviou `/start` para o bot?
- [ ] Username/ID está cadastrado no GLPI?
- [ ] Notificação está ativa no GLPI?
- [ ] Template Telegram está configurado?
- [ ] Cron está rodando?

### ❌ Problema: "Erro ao salvar token"

**Solução:**
- Verifique se copiou o token completo (sem espaços)
- Tente limpar o cache do navegador
- Verifique os logs em `glpi/files/_log/php-errors.log`

### ❌ Problema: "Chat ID vazio no log"

**Solução:**
1. Execute esta query para ver se o usuário está registrado:
   ```sql
   SELECT * FROM glpi_plugin_telegrambot_user;
   ```
2. Se não aparecer, o usuário precisa enviar `/start`
3. Se aparecer, verifique se o username/ID está correto no cadastro

### ❌ Problema: "Tabela MyISAM obsoleta"

**Solução:**
Execute no banco de dados:
```sql
ALTER TABLE glpi_plugin_telegrambot_users ENGINE=InnoDB;
```

### 📋 Verificar Logs

Se nada funciona, verifique os logs:

**No GLPI:**
- `glpi/files/_log/php-errors.log`
- `glpi/files/_log/sql-errors.log`
- `glpi/files/_log/telegrambot.log`

**No Servidor:**
- Linux: `/var/log/apache2/error.log` ou `/var/log/nginx/error.log`
- Windows: `C:\xampp\apache\logs\error.log`

---

## 🎉 Parabéns!

Se você chegou até aqui e está tudo funcionando, **parabéns!** 🎊

Agora você tem um sistema de notificações do GLPI totalmente integrado com o Telegram!

## 📞 Precisa de Ajuda?

- **GitHub Issues**: https://github.com/pluginsGLPI/telegrambot/issues
- **Telegram Group**: https://telegram.me/tgbotglpi
- **Documentação GLPI**: https://glpi-project.org/

---

**Versão do Guia**: 3.0.1  
**Data**: Dezembro 2025  
**Autor**: Comunidade GLPI

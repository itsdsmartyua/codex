# Guia de Atualização - TelegramBot Plugin v3.0.1

## Versões Compatíveis

Este plugin agora é compatível com:
- **GLPI 9.4.x**
- **GLPI 9.5.x**
- **GLPI 10.0.x** (incluindo 10.0.7)
- **GLPI 11.0.x**

## Requisitos

### Sistema
- **PHP**: 7.4, 8.0, 8.1 ou 8.2
- **GLPI**: >= 9.4 e < 11.1

### Extensões PHP Necessárias
- mysqli
- fileinfo
- json
- openssl (recomendado)

## Instalação / Atualização

### 1. Backup
Antes de atualizar, faça backup de:
- Banco de dados do GLPI
- Diretório do plugin: `glpi/plugins/telegrambot/`

### 2. Atualizar Dependências (Opcional)

Se você tiver o Composer instalado, execute:

```bash
cd C:\xampp\htdocs\glpi\plugins\telegrambot
composer update
```

**Nota**: Se você não tiver o Composer instalado, as dependências já incluídas na pasta `vendor/` devem funcionar.

### 3. Reativar o Plugin

No painel administrativo do GLPI:

1. Vá para **Configurar** > **Plugins**
2. Localize o plugin **TelegramBot**
3. Se estiver ativo, clique em **Desativar** e depois em **Ativar** novamente
4. Se não estiver instalado, clique em **Instalar** e depois em **Ativar**

### 4. Verificar Configurações

Após a reativação, verifique:
- Token do bot está configurado
- Nome de usuário do bot está configurado
- Notificações WebSocket estão ativas

## Mudanças Principais na v3.0.1

### Compatibilidade
- ✅ Suporte para GLPI 10.0.x e 11.0.x
- ✅ Suporte para PHP 8.x
- ✅ Atualização da biblioteca longman/telegram-bot para ^0.70

### Segurança
- ✅ Requisito mínimo do PHP atualizado para 7.4
- ✅ Dependências atualizadas para versões mais seguras

## Solução de Problemas

### Plugin não ativa

1. Verifique a versão do PHP:
   ```bash
   C:\xampp\php\php.exe -v
   ```
   Deve ser >= 7.4

2. Verifique a versão do GLPI no painel

3. Verifique os logs em:
   - `glpi/files/_log/php-errors.log`
   - `glpi/files/_log/sql-errors.log`

### Erro de dependências

Se encontrar erros relacionados ao Composer, você pode:

1. Baixar a versão completa do plugin com dependências do GitHub
2. Ou instalar o Composer e executar `composer install`

### Bot não responde

1. Verifique se o token está correto em **Configurar** > **Geral** > **TelegramBot**
2. Execute o cron manualmente: **Administração** > **Automática** > **Executar** (próximo a messagelistener)
3. Configure o webhook ou polling conforme documentação

## Suporte

Para problemas ou questões:
- GitHub Issues: https://github.com/pluginsGLPI/telegrambot/issues
- Documentação GLPI: https://glpi-project.org/

## Notas de Compatibilidade

### GLPI 10.x
- Todas as funcionalidades testadas e funcionando
- Compatível com a nova interface

### GLPI 11.x
- Compatível até a versão 11.0.x
- Para versões futuras (11.1+), pode ser necessária nova atualização

---

**Versão do Plugin**: 3.0.1  
**Data de Atualização**: 17/12/2025  
**Testado com**: GLPI 10.0.7 e GLPI 11.0.0

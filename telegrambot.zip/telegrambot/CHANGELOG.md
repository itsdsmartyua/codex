# Changelog

## [3.0.1] - 2025-12-17

### Adicionado
- Suporte para GLPI 10.0.x
- Suporte para GLPI 11.0.x
- Compatibilidade com PHP 7.4, 8.0, 8.1 e 8.2
- Verificação de versão máxima do GLPI (< 11.1) no check_prerequisites
- **Botão "Testar Conexão"** na página de configuração do bot
- Função de teste de conectividade com a API do Telegram
- Mensagens de feedback ao salvar configurações

### Corrigido
- ✅ Erro de permissão ao salvar as chaves do bot (CSRF duplicado removido)
- ✅ Compatibilidade com GLPI 11.0.1 e superiores (ajuste no max version)
- ✅ Validação adequada do CSRF token em requisições POST

### Alterado
- Atualizada versão mínima do PHP de 7.0 para 7.4
- Atualizada biblioteca longman/telegram-bot para versão ^0.70
- Melhorada compatibilidade com versões modernas do GLPI
- Interface de configuração com botão de teste integrado

### Requisitos
- GLPI >= 9.4 e < 12.0
- PHP >= 7.4

## [3.0.0] - Versão Anterior

### Inicial
- Suporte inicial para GLPI 9.4
- Funcionalidades básicas do bot Telegram

# 🔧 Guia Rápido: Como Fazer os Comandos do Bot Funcionarem

## O Problema

Você envia `/help` ou outros comandos para o bot, mas ele não responde. ❌

## A Causa

**Os comandos do bot só funcionam quando o cron está rodando!**

Diferente do comando `/start` (que é instantâneo), os outros comandos precisam que o GLPI processe as mensagens através do cron.

---

## ✅ Solução Rápida (3 passos)

### 1️⃣ Execute o Script de Teste

Abra o PowerShell no Windows e execute:

```powershell
cd C:\xampp\htdocs\glpi\plugins\telegrambot
C:\xampp\php\php.exe test_commands.php
```

Este script vai:
- ✅ Verificar se tudo está configurado
- ✅ Processar as mensagens pendentes do Telegram
- ✅ Fazer o bot responder aos comandos que você enviou

### 2️⃣ Teste no Telegram

1. Abra o Telegram
2. Envie para o bot: `/help`
3. Aguarde 5-10 segundos
4. **Execute novamente** o script acima
5. O bot deve responder com a lista de comandos! 🎉

### 3️⃣ Configure Execução Automática

Para não precisar executar manualmente sempre:

**Windows (XAMPP):**

1. Crie um arquivo `telegram_cron.bat` com este conteúdo:
   ```batch
   @echo off
   C:\xampp\php\php.exe C:\xampp\htdocs\glpi\front\cron.php
   ```

2. Abra o **Agendador de Tarefas** do Windows:
   - Pressione `Windows + R`
   - Digite: `taskschd.msc`
   - Enter

3. Clique em **"Criar Tarefa Básica"**

4. Preencha:
   - **Nome**: GLPI Telegram Cron
   - **Descrição**: Processa mensagens do bot Telegram
   - Clique em **"Avançar"**

5. **Gatilho**: Selecione **"Diariamente"**
   - Clique em **"Avançar"**
   - Hora: 00:00
   - Clique em **"Avançar"**

6. **Ação**: Selecione **"Iniciar um programa"**
   - Clique em **"Avançar"**
   - **Programa**: `C:\xampp\htdocs\glpi\plugins\telegrambot\telegram_cron.bat`
   - Clique em **"Avançar"**

7. Clique em **"Concluir"**

8. **IMPORTANTE**: Edite a tarefa criada:
   - Na lista de tarefas, encontre **"GLPI Telegram Cron"**
   - Clique com botão direito > **"Propriedades"**
   - Vá na aba **"Gatilhos"**
   - Clique em **"Editar"**
   - Marque **"Repetir tarefa a cada"**
   - Selecione: **5 minutos**
   - **Durante**: 1 dia
   - Clique em **"OK"**

9. Pronto! Agora o cron vai rodar a cada 5 minutos automaticamente! 🎉

---

## 🧪 Como Testar Cada Comando

Depois de configurar o cron, teste cada comando:

### `/help` - Lista de Comandos
```
Envie: /help
Resposta esperada: Lista com todos os comandos disponíveis
```

### `/help <comando>` - Ajuda Específica
```
Envie: /help newticket
Resposta esperada: Descrição detalhada do comando /newticket
```

### `/echo <texto>` - Teste de Eco
```
Envie: /echo Olá bot!
Resposta esperada: Olá bot!
```

### `/newticket` - Criar Chamado
```
Envie: /newticket
Resposta esperada: Instruções para criar um novo chamado
```

### `/searchticket <id>` - Buscar Chamado
```
Envie: /searchticket 123
Resposta esperada: Detalhes do chamado 123
```

---

## 🔍 Diagnóstico de Problemas

### Problema: Script de teste dá erro

**Verifique:**
```powershell
# Teste se o PHP está funcionando
C:\xampp\php\php.exe -v

# Deve mostrar: PHP 8.2.12 (ou sua versão)
```

### Problema: Bot ainda não responde

**Execute o diagnóstico:**
```powershell
cd C:\xampp\htdocs\glpi\plugins\telegrambot
C:\xampp\php\php.exe test_commands.php
```

**Veja os logs:**
```powershell
# Ver últimas linhas do log
Get-Content C:\xampp\htdocs\glpi\files\_log\notification.log -Tail 20
```

### Problema: "Table doesn't exist"

O banco de dados não foi criado corretamente. Execute:

1. No MySQL:
   ```sql
   USE glpi;
   SOURCE C:/xampp/htdocs/glpi/plugins/telegrambot/db/install.sql;
   ```

2. Ou no GLPI:
   - Vá em **"Configurar"** > **"Plugins"**
   - Desinstale o plugin
   - Instale novamente

---

## 📝 Checklist Completo

- [ ] Bot configurado com token e username
- [ ] Plugin ativado no GLPI
- [ ] Enviou `/start` para o bot
- [ ] Executou o cron manualmente (test_commands.php)
- [ ] Bot respondeu ao `/help`
- [ ] Configurou cron automático (Agendador de Tarefas)
- [ ] Testou todos os comandos

---

## 🎯 Resumo

1. **Comandos precisam do cron para funcionar**
2. **Use o script `test_commands.php` para processar mensagens**
3. **Configure o Agendador de Tarefas para rodar a cada 5 minutos**
4. **Aguarde alguns segundos após enviar comandos**

**Pronto! Agora seus comandos devem funcionar! 🚀**

---

## 💡 Dica Extra

Se você está desenvolvendo e testando muito, pode rodar o cron manualmente sempre que precisar:

```powershell
C:\xampp\php\php.exe C:\xampp\htdocs\glpi\front\cron.php
```

Mas lembre-se: **configure o agendador para produção!**

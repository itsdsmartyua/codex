<?php
/*
 * Script de diagnóstico e testes do TelegramBot
 */

include ('../../../inc/includes.php');

Session::checkRight('config', UPDATE);

global $DB;

// Processar envio de teste
if (isset($_POST['send_test'])) {
    $user_id = $_POST['user_id'];
    $message = "🧪 Teste de notificação do GLPI TelegramBot\n\n";
    $message .= "Data/Hora: " . date('d/m/Y H:i:s') . "\n";
    $message .= "Usuário GLPI ID: " . $user_id . "\n\n";
    $message .= "✅ Se você recebeu esta mensagem, o bot está funcionando corretamente!";
    
    PluginTelegrambotBot::sendMessage($user_id, $message);
    
    Session::addMessageAfterRedirect("Mensagem de teste enviada para o usuário ID: $user_id", false, INFO);
    Html::redirect($_SERVER['PHP_SELF']);
}

Html::header(
    'Diagnóstico TelegramBot',
    $_SERVER['PHP_SELF'],
    'config',
    'notification',
    'config'
);

echo "<div class='center'>";
echo "<h1>Diagnóstico e Testes do TelegramBot</h1>";

// 1. Verificar configurações
echo "<div class='spaced'>";
echo "<h2>1. Configurações do Bot</h2>";
$token = PluginTelegrambotBot::getConfig('token');
$username = PluginTelegrambotBot::getConfig('bot_username');
echo "<table class='tab_cadre_fixe'>";
echo "<tr><th>Configuração</th><th>Valor</th></tr>";
echo "<tr><td>Token</td><td>" . (empty($token) ? "<strong style='color:red'>NÃO CONFIGURADO</strong>" : substr($token, 0, 10) . "...") . "</td></tr>";
echo "<tr><td>Username</td><td>" . (empty($username) ? "<strong style='color:red'>NÃO CONFIGURADO</strong>" : "@" . $username) . "</td></tr>";
echo "</table>";
echo "</div>";

// 2. Verificar mapeamento de usuários (GLPI -> Telegram) com botão de teste
echo "<div class='spaced'>";
echo "<h2>2. Usuários GLPI com Telegram configurado</h2>";
$result = $DB->request([
    'SELECT' => ['glpi_plugin_telegrambot_users.id', 'glpi_plugin_telegrambot_users.username', 'glpi_users.name'],
    'FROM' => 'glpi_plugin_telegrambot_users',
    'LEFT JOIN' => [
        'glpi_users' => [
            'FKEY' => [
                'glpi_plugin_telegrambot_users' => 'id',
                'glpi_users' => 'id'
            ]
        ]
    ]
]);

if (count($result) == 0) {
    echo "<p><strong style='color:red'>Nenhum usuário configurado!</strong><br>";
    echo "Configure adicionando o username do Telegram ao perfil do usuário.</p>";
} else {
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr><th>ID GLPI</th><th>Nome GLPI</th><th>Username/ID Telegram</th><th>Status</th><th>Ação</th></tr>";
    foreach ($result as $row) {
        $chat_id = PluginTelegrambotBot::getChatID($row['id']);
        $status = $chat_id ? "<span style='color:green'>✓ Conectado</span>" : "<span style='color:red'>✗ Não conectado</span>";
        
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . ($row['name'] ?? 'N/A') . "</td>";
        echo "<td>@" . $row['username'] . "</td>";
        echo "<td>" . $status . "</td>";
        echo "<td>";
        if ($chat_id) {
            echo "<form method='post' style='display:inline'>";
            echo Html::hidden('user_id', ['value' => $row['id']]);
            echo Html::hidden('_csrf_token', ['value' => Session::getNewCSRFToken()]);
            echo "<button type='submit' name='send_test' class='btn btn-primary'>";
            echo "<i class='fas fa-paper-plane'></i> Enviar Teste";
            echo "</button>";
            echo "</form>";
        } else {
            echo "<span style='color:gray'>Usuário deve enviar /start</span>";
        }
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// 3. Verificar usuários do Telegram que enviaram /start
echo "<div class='spaced'>";
echo "<h2>3. Usuários do Telegram cadastrados (enviaram /start)</h2>";
$result = $DB->request([
    'SELECT' => ['id', 'username', 'first_name', 'last_name'],
    'FROM' => 'glpi_plugin_telegrambot_user'
]);

if (count($result) == 0) {
    echo "<p><strong style='color:red'>Nenhum usuário enviou /start para o bot!</strong><br>";
    echo "Abra o Telegram, procure por @" . $username . " e envie: <code>/start</code></p>";
} else {
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr><th>Telegram ID</th><th>Username</th><th>Nome</th></tr>";
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>@" . ($row['username'] ?? 'N/A') . "</td>";
        echo "<td>" . $row['first_name'] . " " . ($row['last_name'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// 4. Verificar chats disponíveis
echo "<div class='spaced'>";
echo "<h2>4. Chats disponíveis</h2>";
$result = $DB->request([
    'SELECT' => ['id', 'type', 'username', 'first_name'],
    'FROM' => 'glpi_plugin_telegrambot_chat'
]);

if (count($result) == 0) {
    echo "<p><strong style='color:red'>Nenhum chat registrado!</strong></p>";
} else {
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr><th>Chat ID</th><th>Tipo</th><th>Username/Nome</th></tr>";
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . ($row['username'] ? '@' . $row['username'] : $row['first_name']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// 5. Verificar mapeamento user -> chat
echo "<div class='spaced'>";
echo "<h2>5. Mapeamento User-Chat</h2>";
$result = $DB->request([
    'SELECT' => ['user_id', 'chat_id'],
    'FROM' => 'glpi_plugin_telegrambot_user_chat'
]);

if (count($result) == 0) {
    echo "<p><strong style='color:red'>Nenhum mapeamento user-chat!</strong></p>";
} else {
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr><th>User ID</th><th>Chat ID</th></tr>";
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['user_id'] . "</td>";
        echo "<td>" . $row['chat_id'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
echo "</div>";

// 6. Instruções
echo "<div class='spaced'>";
echo "<h2>Próximos Passos</h2>";
echo "<ol>";
echo "<li><strong>Configure o username do Telegram:</strong> Edite cada usuário no GLPI e adicione o username ou ID do Telegram</li>";
echo "<li><strong>Envie /start para o bot:</strong> No Telegram, procure @" . $username . " e envie <code>/start</code></li>";
echo "<li><strong>Execute o cron:</strong> Vá em Administração > Automática > Execute 'messagelistener'</li>";
echo "<li><strong>Recarregue esta página</strong> para atualizar o status</li>";
echo "<li><strong>Clique em 'Enviar Teste'</strong> para validar a conexão com cada usuário</li>";
echo "</ol>";
echo "</div>";

echo "</div>";

Html::footer();

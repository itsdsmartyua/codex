<?php
/*
  -------------------------------------------------------------------------
  TelegramBot plugin for GLPI
  Copyright (C) 2017 by the TelegramBot Development Team.

  https://github.com/pluginsGLPI/telegrambot
  -------------------------------------------------------------------------

  LICENSE

  This file is part of TelegramBot.

  TelegramBot is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  TelegramBot is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
  --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 *  This class manages the sms notifications settings
 */
class PluginTelegrambotNotificationWebsocketSetting extends NotificationSetting {

    static function getTypeName($nb = 0) {
        return __('Telegram followups configuration', 'telegrambot');
    }

    public function getEnableLabel() {
        return __('Enable followups via Telegram', 'telegrambot');
    }

    static public function getMode() {
    return Notification_NotificationTemplate::MODE_MAIL;
}

    function showFormConfig($options = []) {
    global $CFG_GLPI, $DB;

    $bot_token = PluginTelegrambotBot::getConfig('token');
    $bot_username = PluginTelegrambotBot::getConfig('bot_username');
    $global_tech_1 = PluginTelegrambotBot::getConfig('global_tech_1');
    $global_tech_2 = PluginTelegrambotBot::getConfig('global_tech_2');
    $global_tech_3 = PluginTelegrambotBot::getConfig('global_tech_3');

    $form_action = Toolbox::getItemTypeFormURL(__CLASS__);
    $pluralized_translation = _n('Telegram notification', 'Telegram notifications', Session::getPluralNumber());
    $bot_token_translation = __('Bot token');
    $bot_username_translation = __('Bot username');
    $test_connection_translation = __('Testar Conexão');

    echo "<form action='{$form_action}' method='post'>";
    echo Html::hidden('_csrf_token', ['value' => Session::getNewCSRFToken()]);
    echo "<div class='spaced' id='tabsbody'>";
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr class='tab_bg_1'><th colspan='4'>{$pluralized_translation}</th></tr>";
    
    echo "<tr class='tab_bg_2'>";
    echo "<td><label for='bot_token'>{$bot_token_translation}</label></td>";
    echo "<td colspan='3'><input type='text' name='token' id='bot_token' value='{$bot_token}' size='80' style='width: 95%'></td>";
    echo "</tr>";
    
    echo "<tr class='tab_bg_2'>";
    echo "<td><label for='bot_username'>{$bot_username_translation}</label></td>";
    echo "<td><input type='text' name='bot_username' id='bot_username' value='{$bot_username}' size='40'></td>";
    echo "<td colspan='2'>";
    echo "<button type='submit' name='test_connection' class='btn btn-secondary' value='1'>";
    echo "<i class='fas fa-vial'></i> {$test_connection_translation}";
    echo "</button>";
    echo "</td>";
    echo "</tr>";
    
    // Técnicos globais
    echo "<tr class='tab_bg_1'><th colspan='4'>" . __('Técnicos que receberão todas as notificações') . "</th></tr>";
    echo "<tr class='tab_bg_2'>";
    echo "<td colspan='4'><small>" . __('Configure até 3 técnicos que receberão cópia de TODAS as notificações do sistema') . "</small></td>";
    echo "</tr>";
    
    // Buscar lista de usuários para dropdown
    $users_result = $DB->request([
        'SELECT' => ['glpi_plugin_telegrambot_users.id', 'glpi_users.name'],
        'FROM' => 'glpi_plugin_telegrambot_users',
        'INNER JOIN' => [
            'glpi_users' => [
                'FKEY' => [
                    'glpi_plugin_telegrambot_users' => 'id',
                    'glpi_users' => 'id'
                ]
            ]
        ],
        'ORDER' => 'glpi_users.name'
    ]);
    
    $users_options = [0 => '-- Nenhum --'];
    foreach ($users_result as $user) {
        $users_options[$user['id']] = $user['name'];
    }
    
    for ($i = 1; $i <= 3; $i++) {
        $config_key = "global_tech_$i";
        $current_value = PluginTelegrambotBot::getConfig($config_key);
        
        echo "<tr class='tab_bg_2'>";
        echo "<td><label>Técnico Global $i</label></td>";
        echo "<td colspan='3'>";
        echo "<select name='{$config_key}' class='form-select'>";
        foreach ($users_options as $user_id => $user_name) {
            $selected = ($current_value == $user_id) ? 'selected' : '';
            echo "<option value='{$user_id}' {$selected}>{$user_name}</option>";
        }
        echo "</select>";
        echo "</td>";
        echo "</tr>";
    }
    
    if (Session::haveRight('config', UPDATE)) {
        echo "<tr class='tab_bg_2'>";
        echo "<td colspan='4' class='center'>";
        echo "<input type='submit' name='update' value=\"" . __('Save') . "\" class='btn btn-primary'>";
        echo "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    echo "</div>";
    echo Html::closeForm(false);
    
    // Tabela de usuários configurados com botão de teste
    echo "<div class='spaced' style='margin-top: 20px'>";
    echo "<table class='tab_cadre_fixe'>";
    echo "<tr class='tab_bg_1'><th colspan='5'>" . __('Usuários configurados para receber notificações') . "</th></tr>";
    echo "<tr class='tab_bg_2'>";
    echo "<th>ID</th><th>Usuário GLPI</th><th>Telegram</th><th>Status</th><th>Ação</th>";
    echo "</tr>";
    
    $result = $DB->request([
        'SELECT' => ['glpi_plugin_telegrambot_users.id', 'glpi_plugin_telegrambot_users.username', 'glpi_users.name'],
        'FROM' => 'glpi_plugin_telegrambot_users',
        'LEFT JOIN' => [
            'glpi_users' => [
                'FKEY' => [
                    'glpi_plugin_telegrambot_users' => 'id',
                    'glpi_users' => 'id'
                ]
            ]
        ]
    ]);
    
    if (count($result) == 0) {
        echo "<tr class='tab_bg_2'><td colspan='5' class='center'>";
        echo __('Nenhum usuário configurado. Edite os usuários e adicione o username/ID do Telegram.');
        echo "</td></tr>";
    } else {
        foreach ($result as $row) {
            $chat_id = PluginTelegrambotBot::getChatID($row['id']);
            
            echo "<tr class='tab_bg_2'>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . ($row['name'] ?? 'N/A') . "</td>";
            echo "<td>@" . $row['username'] . "</td>";
            
            if ($chat_id) {
                echo "<td><span style='color:green'>✓ Conectado</span></td>";
                echo "<td>";
                $test_url = $form_action . '?send_test=1&user_id=' . $row['id'];
                echo "<a href='{$test_url}' class='btn btn-sm btn-primary'>";
                echo "<i class='fas fa-paper-plane'></i> Enviar Teste";
                echo "</a>";
                echo "</td>";
            } else {
                echo "<td><span style='color:red'>✗ Não conectado</span></td>";
                echo "<td><small>Usuário deve enviar /start para @{$bot_username}</small></td>";
            }
            
            echo "</tr>";
        }
    }
    
    echo "</table>";
    echo "</div>";
}

}